import "dotenv/config";
import express from "express";
import OpenAI from "openai";

const app = express();
app.use(express.json({ limit: "1mb" }));

const port = Number(process.env.PORT || 3000);
const apiKey = process.env.OPENAI_API_KEY;
const client = apiKey ? new OpenAI({ apiKey }) : null;

app.get("/health", (_req, res) => res.json({ ok: true, app: "Ariyan AI" }));

app.post("/chat", async (req, res) => {
  try {
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message) return res.status(400).json({ error: "message is required" });
    if (message.length > 12000) return res.status(413).json({ error: "message too long" });
    if (!client) return res.status(503).json({ error: "AI backend is not configured" });

    const result = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions: "You are Ariyan AI, a helpful assistant. Reply in the language used by the user, preferably Bengali when the user writes Bengali. Be clear and safe.",
      input: message
    });
    return res.json({ reply: result.output_text || "দুঃখিত, উত্তর তৈরি করা যায়নি।" });
  } catch (error) {
    console.error("Chat request failed:", error?.message || error);
    return res.status(500).json({ error: "AI request failed" });
  }
});

app.listen(port, "0.0.0.0", () => {
  console.log(`Ariyan AI backend listening on port ${port}`);
});
