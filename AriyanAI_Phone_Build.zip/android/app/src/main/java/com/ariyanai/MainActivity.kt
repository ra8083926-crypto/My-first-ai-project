package com.ariyanai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

private val Navy = Color(0xFF11152B)
private val Violet = Color(0xFF6D63E8)
private val Ink = Color(0xFF20233A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AriyanApp() }
    }
}

data class ChatMessage(val text: String, val fromUser: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AriyanApp() {
    val messages = remember {
        mutableStateListOf(ChatMessage("আসসালামু আলাইকুম! আমি Ariyan AI। কীভাবে সাহায্য করতে পারি?", false))
    }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Violet, background = Navy, surface = Color(0xFF1B203A),
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Navy,
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Box(Modifier.size(40.dp).background(Violet, CircleShape), contentAlignment = Alignment.Center) {
                                Text("AI", color = Color.White, fontSize = 17.sp)
                            }
                            Column {
                                Text("Ariyan AI", color = Color.White)
                                Text("আপনার ব্যক্তিগত AI সহকারী", color = Color.LightGray, fontSize = 11.sp)
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy)
                )
            },
            bottomBar = {
                Column(Modifier.fillMaxWidth().background(Navy).padding(12.dp)) {
                    error?.let { Text(it, color = Color(0xFFFF9A9A), fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp)) }
                    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = input, onValueChange = { input = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("এখানে লিখুন…", color = Color.LightGray) },
                            shape = RoundedCornerShape(22.dp), maxLines = 4,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                                focusedBorderColor = Violet, unfocusedBorderColor = Color(0xFF555B7A),
                                cursorColor = Violet
                            )
                        )
                        Button(
                            onClick = {
                                val prompt = input.trim()
                                if (prompt.isNotEmpty() && !busy) {
                                    messages.add(ChatMessage(prompt, true))
                                    input = ""; error = null; busy = true
                                    scope.launch {
                                        try {
                                            val answer = askBackend(prompt)
                                            messages.add(ChatMessage(answer, false))
                                        } catch (e: Exception) {
                                            error = "সংযোগ হয়নি। Backend URL ও সার্ভার চালু আছে কি না দেখুন।"
                                        } finally { busy = false }
                                    }
                                }
                            },
                            enabled = input.trim().isNotEmpty() && !busy,
                            modifier = Modifier.height(54.dp),
                            shape = RoundedCornerShape(18.dp),
                            contentPadding = PaddingValues(horizontal = 17.dp, vertical = 12.dp)
                        ) { Text(if (busy) "…" else "➤") }
                    }
                    Text("AI-এর উত্তর ভুল হতে পারে—গুরুত্বপূর্ণ তথ্য যাচাই করুন।", color = Color.Gray, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }
        ) { padding ->
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp),
                contentPadding = PaddingValues(vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(messages) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start) {
                        Surface(
                            color = if (msg.fromUser) Violet else Color(0xFF252B49),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.widthIn(max = 310.dp)
                        ) {
                            Text(msg.text, color = Color.White, modifier = Modifier.padding(14.dp), fontSize = 15.sp, lineHeight = 22.sp)
                        }
                    }
                }
                if (busy) item {
                    Text("Ariyan AI উত্তর তৈরি করছে…", color = Color.LightGray, fontSize = 13.sp)
                }
            }
        }
    }
}

private suspend fun askBackend(prompt: String): String = withContext(Dispatchers.IO) {
    // Emulator default. Replace with your deployed HTTPS backend URL for a real phone/release app.
    val baseUrl = "http://10.0.2.2:3000"
    val json = JSONObject().put("message", prompt).toString()
    val body = json.toRequestBody("application/json; charset=utf-8".toMediaType())
    val request = Request.Builder().url("$baseUrl/chat").post(body).build()
    OkHttpClient().newCall(request).execute().use { response ->
        val responseText = response.body?.string().orEmpty()
        if (!response.isSuccessful) throw IOException("HTTP ${response.code}: $responseText")
        JSONObject(responseText).optString("reply", "উত্তর পাওয়া যায়নি।")
    }
}
