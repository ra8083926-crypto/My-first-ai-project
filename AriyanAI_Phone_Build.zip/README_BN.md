# Ariyan AI — Android starter project

এটি Ariyan AI-এর প্রথম source-code starter। এতে Android chat UI এবং একটি ছোট Node.js backend আছে।

## কী আছে
- Android অ্যাপে chat screen
- বাংলা/ইংরেজি message পাঠানো
- Backend-এর মাধ্যমে AI reply
- API key Android অ্যাপে রাখা হয় না (backend-এর `.env`-এ থাকে)
- ছবি/voice generation-এর UI এবং API integration পরের ধাপে যোগ করতে হবে

## Android অ্যাপ চালানো
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio থেকে `android` ফোল্ডারটি Open করুন।
3. `app/src/main/java/com/ariyanai/MainActivity.kt`-এর `BASE_URL` আপনার backend-এর HTTPS URL দিয়ে বদলান।
4. Run চাপুন অথবা Build > Build APK(s) নির্বাচন করুন।

`BASE_URL`-এর ডিফল্ট `http://10.0.2.2:3000/` শুধু Android Emulator-এর জন্য। আসল ফোনে `localhost` কাজ করবে না; ফোন ও কম্পিউটার একই Wi‑Fi-তে থাকলে কম্পিউটারের LAN IP ব্যবহার করা যায়, কিন্তু release app-এর জন্য HTTPS hosting ব্যবহার করুন।

## AI backend চালানো
1. Node.js 20+ ইনস্টল করুন।
2. `backend` ফোল্ডারে terminal খুলুন।
3. `npm install` চালান।
4. `.env.example` কপি করে `.env` বানান এবং নিজের API key বসান।
5. `npm start` চালান।

API key কখনো Android app source code-এ বা public GitHub-এ রাখবেন না। API provider অনুযায়ী usage charge হতে পারে। API key না থাকলে backend AI উত্তর দিতে পারবে না।

## গুরুত্বপূর্ণ
এটি একটি starter project, প্রস্তুত APK নয়। এখানে ছবি তৈরি, ছবি বিশ্লেষণ, voice conversation, login, chat history sync, rate limiting এবং production security সম্পূর্ণ করা হয়নি। প্রথমে text chat কাজ করান, তারপর ধাপে ধাপে এসব ফিচার যোগ করুন।

## শুধু ফোন দিয়ে APK বানানোর সহজ পথ (GitHub Actions)
1. ZIP ফাইলটি Extract করে `android` ফোল্ডারের সব ফাইল GitHub-এর নতুন repository-তে আপলোড করুন। এই workflow ফাইলটি repository-র `.github/workflows/build-apk.yml`-এ থাকতে হবে; তাই GitHub-এ `android` ফোল্ডারের **ভেতরের সব ফাইল** repository root-এ আপলোড করুন, যাতে `app/`, `settings.gradle.kts`, `build.gradle.kts` এবং `.github/` একই স্তরে থাকে।
2. GitHub-এর **Actions** ট্যাব খুলে `Build Ariyan AI APK` workflow বেছে `Run workflow` চাপুন।
3. Build সফল হলে run-এর **Artifacts** অংশ থেকে `Ariyan-AI-debug-APK` ডাউনলোড করে ZIP extract করুন। ভেতরের `app-debug.apk` ফোনে ইনস্টল করা যাবে।
4. প্রথমবার ইনস্টল করতে Android-এ browser/file manager-এর জন্য “Install unknown apps” অনুমতি চাইতে পারে। কেবল নিজের তৈরি করা build-ই ইনস্টল করুন।

এই APK-তে AI chat backend-এর URL এখনো emulator default; বাস্তব ফোনে কাজ করাতে আগে backend-কে HTTPS-এ host করে `MainActivity.kt`-এর `baseUrl` বদলাতে হবে। AI API key কখনো GitHub repository-তে লিখবেন না। GitHub Actions-এর workflow build করে, কিন্তু নিজে থেকে AI server host করে না।
